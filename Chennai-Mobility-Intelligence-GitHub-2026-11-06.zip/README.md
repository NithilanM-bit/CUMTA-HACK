# Chennai Mobility Intelligence

Front end for a Chennai road and municipal issue tracker, built with Next.js 14 App Router, TypeScript, Tailwind CSS, and Leaflet. Citizen and operations flows use the same API module. Without Supabase environment variables, the project stays in demo mode using `src/data/mock.ts`; after configuration, authentication, incident records, verification history, credits, AI-review queue, and evidence uploads use Supabase.

## Local development

```bash
npm install
npm run dev
```

Open http://localhost:3000. Production: `npm run build` then `npm run start`.

## Supabase backend status

The hosted Supabase project **Chennai Mobility Intelligence** is provisioned in South Asia (Mumbai). The initial schema, row-level security policies, report/verification/admin RPC functions, evidence bucket, server-role grants, 25 Chennai incidents, and 3 AI monitoring posts have been applied. Project URL, browser key, server-only key, and generated admin invitation/PIN values are configured in the ignored local `.env.local` file. Never commit or share that file.

The schema migration and seed are retained under `supabase/` for reproducible setup. New citizen accounts use Supabase email/password auth. Admin registration is server-side and requires the generated invitation token; admin sign-in checks the profile role and the generated six-digit PIN. For security, create your own citizen and GCC admin accounts from the signup pages before using the protected dashboards. The generated admin token and PIN are in `.env.local`; keep those and the server-only key private.

## What remains external

The live AI scan intentionally reports that no ingestion provider is configured. Connect an approved Chennai social feed and NLP service before enabling it. The route planner is ready to call Google Places Autocomplete and Google Routes through server-side API routes. To enable those calls, enable billing and the Places API (New) and Routes API in Google Cloud, create API-restricted keys, and add `GOOGLE_PLACES_API_KEY` and `GOOGLE_ROUTES_API_KEY` to `.env.local` or the hosting provider's server environment. The Google API URLs alone are not API keys. Never prefix keys with `NEXT_PUBLIC_` or commit them. Google Routes API calls are billed; the UI requests routes only when the user presses **Find live route**. Map tiles remain CartoDB and are independent of Google route APIs.

## Demo mode

With no Supabase values, fake sign-in accepts any password and the seeded UI is usable. Demo accounts: `alex@chennaimobility.org` (citizen), `officer@chennaicorporation.gov.in` (admin; any six-digit PIN). Do not use demo-mode credentials as production accounts.
