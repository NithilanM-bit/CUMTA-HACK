import type {ReactNode} from "react";
export function FilterPanel({title="Filter incidents",children}:{title?:string;children:ReactNode}){return <section className="rounded-xl border border-white/10 bg-panel p-4"><p className="mb-4 text-xs font-semibold uppercase tracking-wider text-slate-400">{title}</p><div className="space-y-4">{children}</div></section>}
