import type {Severity} from "@/types";
const styles:Record<Severity,string>={Critical:"border-red-400/20 bg-red-500/10 text-red-300",High:"border-orange-400/20 bg-orange-500/10 text-orange-300",Medium:"border-amber-400/20 bg-amber-500/10 text-amber-300",Low:"border-emerald-400/20 bg-emerald-500/10 text-emerald-300"};
export function SeverityBadge({severity}:{severity:Severity}){return <span className={`inline-flex rounded-full border px-2.5 py-1 text-xs font-medium ${styles[severity]}`}>{severity}</span>}
