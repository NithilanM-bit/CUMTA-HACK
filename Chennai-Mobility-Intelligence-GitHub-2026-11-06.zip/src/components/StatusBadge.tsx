import type {IncidentStatus} from "@/types";
export function StatusBadge({status}:{status:IncidentStatus}){const style=status==="Resolved"?"text-emerald-300 bg-emerald-400/10":status==="Verified"?"text-cyan bg-cyan/10":status==="Verifying"?"text-amber-300 bg-amber-400/10":"text-slate-300 bg-white/10";return <span className={`rounded-full px-2.5 py-1 text-xs ${style}`}>{status}</span>}
