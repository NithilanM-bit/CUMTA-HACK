export function Skeleton({className="h-24"}:{className?:string}){return <div aria-hidden="true" className={`animate-pulse rounded-xl bg-white/[.06] ${className}`}/>}
