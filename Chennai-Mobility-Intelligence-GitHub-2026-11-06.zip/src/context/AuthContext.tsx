"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import type { MockUser, Role } from "@/types";
import * as api from "@/lib/api";
interface SignupFields { password?: string; phone?: string; employeeId?: string; zone?: string; token?: string }
interface AuthValue { user: MockUser | null; loading: boolean; signIn: (email: string, password: string, role: Role, pin?: string) => Promise<MockUser>; signUp: (name: string, email: string, role: Role, fields?: SignupFields) => Promise<MockUser>; signOut: () => void; updateCredits: (delta: number) => void }
const AuthContext = createContext<AuthValue | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<MockUser | null>(null); const [loading, setLoading] = useState(true);
  useEffect(() => { let alive = true; api.restoreSession().then((current) => { if (alive) setUser(current); }).catch(() => { if (alive) setUser(null); }).finally(() => { if (alive) setLoading(false); }); return () => { alive = false; }; }, []);
  const persist = (next: MockUser) => { setUser(next); localStorage.setItem("cmi-user", JSON.stringify(next)); };
  const signIn = useCallback(async (email: string, password: string, role: Role, pin?: string) => { const next = await api.login(email, password, role, pin); persist(next); return next; }, []);
  const signUp = useCallback(async (name: string, email: string, role: Role, fields?: SignupFields) => { const next = await api.signup(name, email, role, fields); persist(next); return next; }, []);
  const signOut = useCallback(() => { setUser(null); localStorage.removeItem("cmi-user"); void api.logout(); }, []);
  const updateCredits = useCallback((delta: number) => setUser((current) => { if (!current) return current; if (delta === 0) return current; const next = { ...current, credits: current.credits + delta }; localStorage.setItem("cmi-user", JSON.stringify(next)); localStorage.setItem(`cmi-credits:${next.email.toLowerCase()}`, String(next.credits)); return next; }), []);
  const value = useMemo(() => ({ user, loading, signIn, signUp, signOut, updateCredits }), [user, loading, signIn, signUp, signOut, updateCredits]);
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
export function useAuth() { const value = useContext(AuthContext); if (!value) throw new Error("useAuth must be used within AuthProvider"); return value; }
