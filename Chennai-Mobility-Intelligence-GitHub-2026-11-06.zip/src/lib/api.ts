import { incidents as seedIncidents, users as seedUsers, socialPosts as seedPosts, kpis as seedKpis } from "@/data/mock";
import { getSupabase, isSupabaseConfigured } from "@/lib/supabase";
import type { Incident, MockUser, Role, SocialPost, Category } from "@/types";

const pause = (ms = 280) => new Promise((resolve) => setTimeout(resolve, ms));
type DbIncident = Record<string, any>;
const fromDb = (row: DbIncident): Incident => ({ id: row.id, title: row.title, description: row.description, category: row.category, severity: row.severity, status: row.status, address: row.address, lat: Number(row.lat), lng: Number(row.lng), reportedAt: row.reported_at, occurredAt: row.occurred_at ?? undefined, verifiedCount: row.verified_count, disputedCount: row.disputed_count, source: row.source, reporter: row.reporter, imageUrl: row.image_url ?? "", confidence: row.confidence == null ? undefined : Number(row.confidence), sentiment: row.sentiment ?? undefined, sourceText: row.source_text ?? undefined });
const toUser = (profile: DbIncident, email: string): MockUser => ({ id: profile.id, name: profile.full_name, email, role: profile.role, credits: profile.credits, zone: profile.zone ?? "Chennai" });
const check = (error: { message: string } | null) => { if (error) throw new Error(error.message); };
function persistReporterCredits(user: MockUser) { if (typeof window !== "undefined") try { window.localStorage.setItem(`cmi-credits:${user.email.toLowerCase()}`, String(user.credits)); } catch {} }

export async function getIncidents(): Promise<Incident[]> {
  if (!isSupabaseConfigured) { await pause(); return structuredClone(seedIncidents); }
  const { data, error } = await getSupabase().from("incidents").select("*").order("reported_at", { ascending: false }); check(error); return (data ?? []).map(fromDb);
}
export async function getIncident(id: string): Promise<Incident | undefined> {
  if (!isSupabaseConfigured) { await pause(); return structuredClone(seedIncidents.find((item) => item.id === id)); }
  const { data, error } = await getSupabase().from("incidents").select("*").eq("id", id).maybeSingle(); check(error); return data ? fromDb(data) : undefined;
}
export async function createReport(input: Partial<Incident>): Promise<Incident> {
  if (!isSupabaseConfigured) { await pause(600); const item: Incident = { ...seedIncidents[0], ...input, id: `CHN-${Date.now().toString().slice(-6)}`, status: "Reported", reportedAt: new Date().toISOString(), verifiedCount: 0, disputedCount: 0, source: "Citizen" }; seedIncidents.unshift(item); const reporter = seedUsers.find((user) => user.name === item.reporter); if (reporter) { reporter.credits += 25; persistReporterCredits(reporter); } return structuredClone(item); }
  const { data: authData } = await getSupabase().auth.getUser(); if (!authData.user) throw new Error("Sign in to submit a report.");
  const { data, error } = await getSupabase().rpc("submit_incident", { payload: { ...input, reporter: input.reporter ?? authData.user.email } }); check(error); return fromDb(data);
}
export async function uploadIncidentImage(file: File): Promise<string> {
  if (!isSupabaseConfigured) return URL.createObjectURL(file);
  const client = getSupabase(); const { data: { user } } = await client.auth.getUser(); if (!user) throw new Error("Sign in before uploading incident evidence.");
  const ext = file.name.split(".").pop()?.toLowerCase() || "jpg"; const path = `${user.id}/${crypto.randomUUID()}.${ext}`;
  const { error } = await client.storage.from("incident-evidence").upload(path, file, { contentType: file.type || "image/jpeg", upsert: false }); check(error);
  return client.storage.from("incident-evidence").getPublicUrl(path).data.publicUrl;
}
export async function verifyIncident(id: string, verdict: "confirm" | "fake"): Promise<{ incident: Incident; reporter?: MockUser } | undefined> {
  if (!isSupabaseConfigured) { await pause(); const item = seedIncidents.find((incident) => incident.id === id); if (!item) return; item[verdict === "confirm" ? "verifiedCount" : "disputedCount"]++; const reporter = seedUsers.find((user) => user.name === item.reporter); if (reporter) { reporter.credits += verdict === "confirm" ? 10 : -10; persistReporterCredits(reporter); } return { incident: structuredClone(item), reporter: reporter ? structuredClone(reporter) : undefined }; }
  const client = getSupabase(); const { data, error } = await client.rpc("verify_incident", { target_id: id, vote: verdict }); check(error); const incident = fromDb(data);
  let reporter: MockUser | undefined; if (data.reporter_id) { const { data: current } = await client.auth.getUser(); const { data: profile } = await client.from("profiles").select("*").eq("id", data.reporter_id).maybeSingle(); if (profile && current.user) reporter = toUser(profile, current.user.id === data.reporter_id ? current.user.email ?? "" : ""); }
  return { incident, reporter };
}
export async function resolveIncident(id: string): Promise<Incident | undefined> {
  if (!isSupabaseConfigured) { await pause(); const item = seedIncidents.find((incident) => incident.id === id); if (!item) return; item.status = "Resolved"; return structuredClone(item); }
  const { data, error } = await getSupabase().rpc("admin_set_incident_status", { target_id: id, next_status: "Resolved" }); check(error); return data ? fromDb(data) : undefined;
}
export async function login(email: string, password: string, role: Role, pin?: string): Promise<MockUser> {
  if (!isSupabaseConfigured) { await pause(450); const known = seedUsers.find((user) => user.role === role && user.email.toLowerCase() === email.toLowerCase()); const user = structuredClone(known ?? { id: `u-${Date.now()}`, name: role === "admin" ? "Operations Officer" : "Chennai Commuter", email, role, credits: 100, zone: "Chennai" }); if (typeof window !== "undefined") { const saved = window.localStorage.getItem(`cmi-credits:${email.toLowerCase()}`); if (saved !== null && Number.isFinite(Number(saved))) user.credits = Number(saved); } return user; }
  const client = getSupabase(); const { data: auth, error } = await client.auth.signInWithPassword({ email, password }); check(error); if (!auth.user) throw new Error("Could not sign in.");
  const { data: profile, error: profileError } = await client.from("profiles").select("*").eq("id", auth.user.id).single(); check(profileError);
  if (profile.role !== role) { await client.auth.signOut(); throw new Error(role === "admin" ? "This account does not have an admin role." : "Use the admin sign-in portal for this account."); }
  if (role === "admin") { const result = await fetch("/api/auth/admin-check", { method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${auth.session.access_token}` }, body: JSON.stringify({ pin }) }); if (!result.ok) { await client.auth.signOut(); throw new Error((await result.json()).error ?? "Admin security check failed."); } }
  return toUser(profile, auth.user.email ?? email);
}
export async function signup(name: string, email: string, role: Role, fields: { password?: string; phone?: string; employeeId?: string; zone?: string; token?: string } = {}): Promise<MockUser> {
  if (!isSupabaseConfigured) { await pause(500); const user: MockUser = { id: `u-${Date.now()}`, name, email, role, credits: 100, zone: fields.zone ?? "Chennai" }; seedUsers.push(user); persistReporterCredits(user); return structuredClone(user); }
  if (role === "admin") {
    const response = await fetch("/api/auth/admin-signup", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name, email, password: fields.password, phone: fields.phone, employeeId: fields.employeeId, zone: fields.zone, token: fields.token }) }); const body = await response.json(); if (!response.ok) throw new Error(body.error ?? "Admin registration failed.");
    throw new Error("Admin account created. Sign in using the new password and your six-digit operations PIN.");
  }
  const { data, error } = await getSupabase().auth.signUp({ email, password: fields.password ?? "", options: { data: { full_name: name, phone: fields.phone, zone: fields.zone ?? "Chennai" } } }); check(error); if (!data.session) throw new Error("Account created. Please sign in with your email and password.");
  const { data: profile, error: profileError } = await getSupabase().from("profiles").select("*").eq("id", data.user!.id).single(); check(profileError); return toUser(profile, email);
}
export async function restoreSession(): Promise<MockUser | null> {
  if (!isSupabaseConfigured) { try { const saved = window.localStorage.getItem("cmi-user"); return saved ? JSON.parse(saved) as MockUser : null; } catch { return null; } }
  const client = getSupabase(); const { data: { user } } = await client.auth.getUser(); if (!user) return null; const { data: profile } = await client.from("profiles").select("*").eq("id", user.id).maybeSingle(); return profile ? toUser(profile, user.email ?? "") : null;
}
export async function logout() { if (isSupabaseConfigured) { const { error } = await getSupabase().auth.signOut(); check(error); } }
export async function updateCredits(_delta: number) { if (isSupabaseConfigured) return; }
export async function getSocialPosts(): Promise<SocialPost[]> {
  if (!isSupabaseConfigured) { await pause(); return structuredClone(seedPosts); }
  const { data, error } = await getSupabase().from("social_posts").select("*").eq("status", "pending").order("created_at", { ascending: false }); check(error); return (data ?? []).map((row) => ({ id: row.id, source: row.source, handle: row.handle, postedAt: row.posted_at, text: row.text, language: row.language, extraction: row.extraction } as SocialPost));
}
export async function runAiScan(): Promise<SocialPost[]> {
  if (!isSupabaseConfigured) { await pause(1500); seedPosts.unshift({ ...seedPosts[0], id: `post-${Date.now()}`, postedAt: "just now", text: "Lane closure reported on OMR near Perungudi during evening commute." }); return structuredClone(seedPosts); }
  throw new Error("No AI ingestion provider is configured. Connect an approved feed or AI endpoint before running a live scan.");
}
export async function approveSocialPost(id: string): Promise<Incident | undefined> {
  if (!isSupabaseConfigured) { await pause(350); const post = seedPosts.find((item) => item.id === id); if (!post) return; const item: Incident = { id: `CHN-${Date.now().toString().slice(-6)}`, title: `${post.extraction.category} near ${post.extraction.location}`, description: post.text, category: post.extraction.category, severity: post.extraction.severity, status: "Verified", address: post.extraction.location, lat: 13.04, lng: 80.22, reportedAt: new Date().toISOString(), verifiedCount: 0, disputedCount: 0, source: "AI", reporter: post.handle, imageUrl: "https://images.unsplash.com/photo-1519608487953-e999c86e7455?auto=format&fit=crop&w=900&q=75", confidence: post.extraction.confidence, sentiment: post.extraction.sentiment, sourceText: post.text }; seedIncidents.unshift(item); return structuredClone(item); }
  const { data, error } = await getSupabase().rpc("admin_convert_social_post", { post_id: id }); check(error); return data ? fromDb(data) : undefined;
}
export async function rejectSocialPost(id: string): Promise<void> { if (!isSupabaseConfigured) { await pause(); return; } const { error } = await getSupabase().from("social_posts").update({ status: "rejected" }).eq("id", id); check(error); }
export async function getKpis() { if (!isSupabaseConfigured) { await pause(); return structuredClone(seedKpis); } const { data, error } = await getSupabase().from("incidents").select("status,severity,confidence"); check(error); const rows = data ?? []; return [{ label: "Active Incidents", value: String(rows.filter((row) => row.status !== "Resolved").length), change: "Live database", tone: "blue" as const }, { label: "Awaiting Verification", value: String(rows.filter((row) => row.status === "Reported" || row.status === "Verifying").length), change: "Citizen and AI reports", tone: "amber" as const }, { label: "Resolved Today", value: String(rows.filter((row) => row.status === "Resolved").length), change: "All-time total", tone: "green" as const }, { label: "AI Confidence", value: `${rows.length ? (rows.reduce((sum, row) => sum + Number(row.confidence ?? 0), 0) / rows.length).toFixed(1) : "0.0"}%`, change: "Across ingested AI reports", tone: "blue" as const }]; }
export async function getCategories(): Promise<Category[]> { await pause(80); return ["Pothole", "Roadblock", "Municipal work", "Heavy traffic", "Waterlogging", "Signal malfunction", "Accident", "Fallen tree"]; }

export interface PlaceSuggestion { placeId: string; text: string }
export interface RouteWaypoint { address: string; placeId?: string }
export interface GoogleRoute { distanceMeters: number; duration: string; encodedPolyline: string }
export function decodeGooglePolyline(encoded: string): [number, number][] {
  const points: [number, number][] = []; let index = 0; let latitude = 0; let longitude = 0;
  while (index < encoded.length) {
    let result = 0; let shift = 0; let byte: number;
    do { byte = encoded.charCodeAt(index++) - 63; result |= (byte & 0x1f) << shift; shift += 5; } while (byte >= 0x20 && index < encoded.length);
    latitude += result & 1 ? ~(result >> 1) : result >> 1;
    result = 0; shift = 0;
    do { byte = encoded.charCodeAt(index++) - 63; result |= (byte & 0x1f) << shift; shift += 5; } while (byte >= 0x20 && index < encoded.length);
    longitude += result & 1 ? ~(result >> 1) : result >> 1;
    points.push([latitude / 1e5, longitude / 1e5]);
  }
  return points;
}
async function googleAuthHeaders(): Promise<Record<string, string>> {
  if (!isSupabaseConfigured) throw new Error("Connect Supabase sign-in before using live map services.");
  const { data: { session } } = await getSupabase().auth.getSession(); if (!session) throw new Error("Sign in to use live map services.");
  return { Authorization: `Bearer ${session.access_token}` };
}
export async function searchGooglePlaces(input: string): Promise<PlaceSuggestion[]> {
  const headers = await googleAuthHeaders(); const response = await fetch(`/api/maps/places?input=${encodeURIComponent(input)}`, { headers }); const body = await response.json();
  if (!response.ok) throw new Error(body.error ?? "Place search failed."); return body.suggestions as PlaceSuggestion[];
}
export async function calculateGoogleRoutes(origin: RouteWaypoint, destination: RouteWaypoint): Promise<GoogleRoute[]> {
  const headers = await googleAuthHeaders(); const response = await fetch("/api/maps/routes", { method: "POST", headers: { ...headers, "Content-Type": "application/json" }, body: JSON.stringify({ origin, destination }) }); const body = await response.json();
  if (!response.ok) throw new Error(body.error ?? "Route calculation failed."); return body.routes as GoogleRoute[];
}
