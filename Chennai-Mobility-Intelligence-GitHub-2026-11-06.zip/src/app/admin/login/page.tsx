import {AuthShell} from "@/components/AuthShell";export default function AdminLogin(){return <AuthShell role="admin" mode="login"/>}
