import {AuthShell} from "@/components/AuthShell";export default function AdminSignup(){return <AuthShell role="admin" mode="signup"/>}
