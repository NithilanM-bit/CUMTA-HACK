import {AuthShell} from "@/components/AuthShell";export default function Login(){return <AuthShell role="citizen" mode="login"/>}
