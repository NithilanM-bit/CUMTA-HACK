import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

export async function POST(request: Request) {
  try {
    const { name, email, password, phone, employeeId, zone, token } = await request.json();
    const url = process.env.NEXT_PUBLIC_SUPABASE_URL; const serviceKey = process.env.SUPABASE_SECRET_KEY ?? process.env.SUPABASE_SERVICE_ROLE_KEY; const accessToken = process.env.ADMIN_ACCESS_TOKEN;
    if (!url || !serviceKey || !accessToken) return NextResponse.json({ error: "Admin registration is not configured on the server." }, { status: 503 });
    if (!name || !email || !password || !employeeId || !token || token !== accessToken) return NextResponse.json({ error: "The admin clearance code or required fields are invalid." }, { status: 403 });
    if (String(password).length < 12) return NextResponse.json({ error: "Admin passwords must have at least 12 characters." }, { status: 400 });
    const admin = createClient(url, serviceKey, { auth: { autoRefreshToken: false, persistSession: false } });
    const { data: created, error: createError } = await admin.auth.admin.createUser({ email, password, phone, email_confirm: true, user_metadata: { full_name: name, phone, zone } });
    if (createError) return NextResponse.json({ error: createError.message }, { status: 400 });
    if (!created.user) return NextResponse.json({ error: "Could not create the admin account." }, { status: 500 });
    const { error: profileError } = await admin.from("profiles").upsert({ id: created.user.id, full_name: name, role: "admin", phone, employee_id: employeeId, zone: zone ?? "Chennai" });
    if (profileError) return NextResponse.json({ error: `The admin invite was sent, but the profile needs operator repair: ${profileError.message}` }, { status: 500 });
    return NextResponse.json({ ok: true });
  } catch { return NextResponse.json({ error: "Invalid admin registration request." }, { status: 400 }); }
}
