import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";
import { timingSafeEqual } from "node:crypto";

export async function POST(request: Request) {
  try {
    const pin = String((await request.json()).pin ?? ""); const authorization = request.headers.get("authorization") ?? ""; const token = authorization.startsWith("Bearer ") ? authorization.slice(7) : "";
    const url = process.env.NEXT_PUBLIC_SUPABASE_URL; const anon = process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY ?? process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY; const serviceKey = process.env.SUPABASE_SECRET_KEY ?? process.env.SUPABASE_SERVICE_ROLE_KEY; const expectedPin = process.env.ADMIN_LOGIN_PIN;
    if (!url || !anon || !serviceKey || !expectedPin) return NextResponse.json({ error: "Admin PIN verification is not configured." }, { status: 503 });
    if (!token || !/^\d{6}$/.test(pin)) return NextResponse.json({ error: "Enter the six-digit admin security PIN." }, { status: 401 });
    const authClient = createClient(url, anon, { global: { headers: { Authorization: `Bearer ${token}` } }, auth: { persistSession: false, autoRefreshToken: false } });
    const { data: { user }, error } = await authClient.auth.getUser(); if (error || !user) return NextResponse.json({ error: "Your sign-in session is invalid. Sign in again." }, { status: 401 });
    const admin = createClient(url, serviceKey, { auth: { persistSession: false, autoRefreshToken: false } }); const { data: profile, error: profileError } = await admin.from("profiles").select("role").eq("id", user.id).maybeSingle();
    if (profileError || profile?.role !== "admin") return NextResponse.json({ error: "This account is not authorized for the operations portal." }, { status: 403 });
    const pinBuffer = Buffer.from(pin); const expectedBuffer = Buffer.from(expectedPin); if (pinBuffer.length !== expectedBuffer.length || !timingSafeEqual(pinBuffer, expectedBuffer)) return NextResponse.json({ error: "The security PIN is incorrect." }, { status: 401 });
    return NextResponse.json({ ok: true });
  } catch { return NextResponse.json({ error: "Admin security verification failed." }, { status: 400 }); }
}
