import { NextResponse } from "next/server";
import { requireGoogleApiUser } from "@/lib/server/googleAuth";

type WaypointInput = { address?: string; placeId?: string };
type GoogleRoute = { distanceMeters: number; duration: string; polyline?: { encodedPolyline?: string } };
function validWaypoint(point: WaypointInput) { return Boolean((point.placeId && point.placeId.length < 256) || (point.address && point.address.trim().length >= 3 && point.address.length <= 160)); }
function waypoint(point: WaypointInput) { return point.placeId ? { placeId: point.placeId } : { address: point.address!.trim() }; }

export async function POST(request: Request) {
  if (!(await requireGoogleApiUser(request))) return NextResponse.json({ error: "Sign in to calculate a route." }, { status: 401 });
  let body: { origin?: WaypointInput; destination?: WaypointInput };
  try { body = await request.json(); } catch { return NextResponse.json({ error: "Invalid route request." }, { status: 400 }); }
  if (!body.origin || !body.destination || !validWaypoint(body.origin) || !validWaypoint(body.destination)) return NextResponse.json({ error: "Choose a starting point and destination." }, { status: 400 });
  const key = process.env.GOOGLE_ROUTES_API_KEY ?? process.env.GOOGLE_MAPS_API_KEY;
  if (!key) return NextResponse.json({ error: "Google Routes is not configured. Add GOOGLE_ROUTES_API_KEY on the server." }, { status: 503 });
  try {
    const response = await fetch("https://routes.googleapis.com/directions/v2:computeRoutes", {
      method: "POST", headers: { "Content-Type": "application/json", "X-Goog-Api-Key": key, "X-Goog-FieldMask": "routes.duration,routes.distanceMeters,routes.polyline.encodedPolyline" },
      body: JSON.stringify({ origin: waypoint(body.origin), destination: waypoint(body.destination), travelMode: "DRIVE", routingPreference: "TRAFFIC_AWARE_OPTIMAL", computeAlternativeRoutes: true, languageCode: "en-IN", units: "METRIC" }), cache: "no-store",
    });
    const payload = await response.json();
    if (!response.ok) return NextResponse.json({ error: payload.error?.message ?? "Google Routes request failed." }, { status: response.status });
    const routes = (payload.routes ?? []).map((route: GoogleRoute) => ({ distanceMeters: route.distanceMeters, duration: route.duration, encodedPolyline: route.polyline?.encodedPolyline ?? "" }));
    if (!routes.length) return NextResponse.json({ error: "No driving route was found for those places." }, { status: 404 });
    return NextResponse.json({ routes });
  } catch { return NextResponse.json({ error: "Google Routes could not be reached." }, { status: 502 }); }
}
