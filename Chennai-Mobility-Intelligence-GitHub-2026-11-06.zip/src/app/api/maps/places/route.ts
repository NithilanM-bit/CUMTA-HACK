import { NextResponse } from "next/server";
import { requireGoogleApiUser } from "@/lib/server/googleAuth";

export async function GET(request: Request) {
  if (!(await requireGoogleApiUser(request))) return NextResponse.json({ error: "Sign in to search places." }, { status: 401 });
  const input = new URL(request.url).searchParams.get("input")?.trim() ?? "";
  if (input.length < 3) return NextResponse.json({ suggestions: [] });
  if (input.length > 120) return NextResponse.json({ error: "Search text is too long." }, { status: 400 });
  const key = process.env.GOOGLE_PLACES_API_KEY ?? process.env.GOOGLE_MAPS_API_KEY;
  if (!key) return NextResponse.json({ error: "Google Places is not configured. Add GOOGLE_PLACES_API_KEY on the server." }, { status: 503 });
  try {
    const response = await fetch("https://places.googleapis.com/v1/places:autocomplete", {
      method: "POST", headers: { "Content-Type": "application/json", "X-Goog-Api-Key": key, "X-Goog-FieldMask": "suggestions.placePrediction.placeId,suggestions.placePrediction.text.text,suggestions.placePrediction.structuredFormat.mainText.text,suggestions.placePrediction.structuredFormat.secondaryText.text" },
      body: JSON.stringify({
        input,
        includedRegionCodes: ["in"],
        regionCode: "IN",
        languageCode: "en",
        includeQueryPredictions: false,
        locationBias: {
          circle: {
            center: { latitude: 13.0827, longitude: 80.2707 },
            radius: 50000,
          },
        },
      }),
      cache: "no-store",
    });
    const payload: { error?: { message?: string }; suggestions?: Array<{ placePrediction?: { placeId?: string; text?: { text?: string } } }> } = await response.json();
    if (!response.ok) return NextResponse.json({ error: payload.error?.message ?? "Google Places request failed." }, { status: response.status });
    const suggestions = (payload.suggestions ?? []).flatMap((item) => {
      const prediction = item.placePrediction;
      return prediction?.placeId && prediction.text?.text ? [{ placeId: prediction.placeId, text: prediction.text.text }] : [];
    });
    return NextResponse.json({ suggestions });
  } catch { return NextResponse.json({ error: "Google Places could not be reached." }, { status: 502 }); }
}
