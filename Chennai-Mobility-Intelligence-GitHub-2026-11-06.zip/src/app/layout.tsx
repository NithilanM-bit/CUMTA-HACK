import type {Metadata} from "next";
import "./globals.css";
import {AuthProvider} from "@/context/AuthContext";
export const metadata:Metadata={title:"Chennai Mobility Intelligence",description:"Real-time road and municipal issue intelligence for Chennai."};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body><AuthProvider>{children}</AuthProvider></body></html>}
