import {Navbar} from "@/components/Navbar";import {ReportErrorCard} from "@/components/ReportErrorCard";
export default function ReportError(){return <><Navbar/><ReportErrorCard/></>}
