import {AuthShell} from "@/components/AuthShell";export default function Signup(){return <AuthShell role="citizen" mode="signup"/>}
