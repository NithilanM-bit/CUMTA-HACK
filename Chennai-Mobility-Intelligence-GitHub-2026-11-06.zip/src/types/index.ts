export type Role="citizen"|"admin";
export type Severity="Critical"|"High"|"Medium"|"Low";
export type IncidentStatus="Reported"|"Verifying"|"Verified"|"Resolved";
export type IncidentSource="AI"|"Citizen";
export type Category="Pothole"|"Roadblock"|"Municipal work"|"Heavy traffic"|"Waterlogging"|"Signal malfunction"|"Accident"|"Fallen tree";
export interface Incident {id:string;title:string;description:string;category:Category;severity:Severity;status:IncidentStatus;address:string;lat:number;lng:number;reportedAt:string;occurredAt?:string;verifiedCount:number;disputedCount:number;source:IncidentSource;reporter:string;imageUrl:string;confidence?:number;sentiment?:string;sourceText?:string}
export interface MockUser {id:string;name:string;email:string;role:Role;credits:number;zone?:string}
export interface SocialPost {id:string;source:string;handle:string;postedAt:string;text:string;language:string;extraction:{location:string;category:Category;severity:Severity;confidence:number;sentiment:string}}
export interface Kpi {label:string;value:string;change:string;tone:"blue"|"green"|"amber"|"red"}
