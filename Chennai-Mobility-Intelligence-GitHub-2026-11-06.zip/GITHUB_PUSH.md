# Push this project to GitHub

1. Unzip this folder and open it in a terminal.
2. Create an empty repository on GitHub and copy its HTTPS URL.
3. Run these commands from the project folder, replacing the URL:

```powershell
git init
git add .
git commit -m "Add Chennai Mobility Intelligence"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

`.env.local` is intentionally not included. For local development, copy `.env.example` to `.env.local` and add your own Supabase and Google API values. Never commit `.env.local` or publish server-only keys.
