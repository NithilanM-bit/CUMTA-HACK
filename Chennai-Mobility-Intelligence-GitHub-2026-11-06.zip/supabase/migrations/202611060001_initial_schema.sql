-- Chennai Mobility Intelligence: initial Supabase schema.
-- Run from the Supabase SQL editor after creating a project.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  role text not null default 'citizen' check (role in ('citizen', 'admin')),
  credits integer not null default 100,
  phone text,
  employee_id text,
  zone text default 'Chennai',
  created_at timestamptz not null default now()
);

create table if not exists public.incidents (
  id text primary key default ('CHN-' || upper(substr(encode(gen_random_bytes(4), 'hex'), 1, 6))),
  title text not null,
  description text not null,
  category text not null,
  severity text not null check (severity in ('Critical','High','Medium','Low')),
  status text not null default 'Reported' check (status in ('Reported','Verifying','Verified','Resolved')),
  address text not null,
  lat double precision not null,
  lng double precision not null,
  reported_at timestamptz not null default now(),
  occurred_at timestamptz,
  verified_count integer not null default 0,
  disputed_count integer not null default 0,
  source text not null default 'Citizen' check (source in ('AI','Citizen')),
  reporter_id uuid references public.profiles(id) on delete set null,
  reporter text not null,
  image_url text,
  confidence numeric,
  sentiment text,
  source_text text,
  created_at timestamptz not null default now()
);

create table if not exists public.incident_verifications (
  id uuid primary key default gen_random_uuid(),
  incident_id text not null references public.incidents(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  verdict text not null check (verdict in ('confirm','fake')),
  created_at timestamptz not null default now(),
  unique (incident_id, user_id)
);

create table if not exists public.social_posts (
  id text primary key,
  source text not null,
  handle text not null,
  posted_at text not null,
  text text not null,
  language text not null default 'English',
  extraction jsonb not null,
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  created_at timestamptz not null default now()
);

create index if not exists incidents_status_created on public.incidents(status, created_at desc);
create index if not exists incidents_reporter on public.incidents(reporter_id);
create index if not exists social_posts_status_created on public.social_posts(status, created_at desc);

create or replace function public.current_user_is_admin()
returns boolean language sql stable security definer set search_path = public
as $$ select exists(select 1 from public.profiles where id = auth.uid() and role = 'admin'); $$;

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public
as $$ begin
  insert into public.profiles (id, full_name, phone, zone)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name', split_part(new.email, '@', 1)), new.raw_user_meta_data->>'phone', coalesce(new.raw_user_meta_data->>'zone','Chennai'))
  on conflict (id) do nothing;
  return new;
end; $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

create or replace function public.submit_incident(payload jsonb)
returns public.incidents language plpgsql security definer set search_path = public
as $$ declare result public.incidents; reporter_name text; reporter_credits integer; begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  select full_name,credits into reporter_name,reporter_credits from public.profiles where id=auth.uid();
  if reporter_credits < -50 then raise exception 'Restricted account: reporting is disabled below -50 credits'; end if;
  insert into public.incidents(title,description,category,severity,address,lat,lng,occurred_at,reporter_id,reporter,image_url,source)
  values(payload->>'title',payload->>'description',payload->>'category',payload->>'severity',payload->>'address',(payload->>'lat')::float8,(payload->>'lng')::float8,nullif(payload->>'occurredAt','')::timestamptz,auth.uid(),reporter_name,payload->>'imageUrl','Citizen') returning * into result;
  update public.profiles set credits=credits+25 where id=auth.uid();
  return result;
end; $$;

create or replace function public.verify_incident(target_id text, vote text)
returns public.incidents language plpgsql security definer set search_path = public
as $$ declare result public.incidents; owner_id uuid; begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  if vote not in ('confirm','fake') then raise exception 'Invalid verification vote'; end if;
  insert into public.incident_verifications(incident_id,user_id,verdict) values(target_id,auth.uid(),vote);
  update public.incidents set verified_count=verified_count + case when vote='confirm' then 1 else 0 end,
    disputed_count=disputed_count + case when vote='fake' then 1 else 0 end where id=target_id returning * into result;
  if not found then raise exception 'Incident not found'; end if;
  owner_id := result.reporter_id;
  if owner_id is not null then update public.profiles set credits=credits + case when vote='confirm' then 10 else -10 end where id=owner_id; end if;
  return result;
end; $$;

create or replace function public.admin_set_incident_status(target_id text, next_status text)
returns public.incidents language plpgsql security definer set search_path = public
as $$ declare result public.incidents; begin
  if not public.current_user_is_admin() then raise exception 'Admin role required'; end if;
  if next_status not in ('Reported','Verifying','Verified','Resolved') then raise exception 'Invalid incident status'; end if;
  update public.incidents set status=next_status where id=target_id returning * into result;
  return result;
end; $$;

create or replace function public.admin_convert_social_post(post_id text)
returns public.incidents language plpgsql security definer set search_path = public
as $$ declare source_post public.social_posts; result public.incidents; extracted jsonb; begin
  if not public.current_user_is_admin() then raise exception 'Admin role required'; end if;
  select * into source_post from public.social_posts where id=post_id and status='pending' for update;
  if not found then raise exception 'Pending social post not found'; end if;
  extracted := source_post.extraction;
  insert into public.incidents(title,description,category,severity,status,address,lat,lng,source,reporter,image_url,confidence,sentiment,source_text)
  values(extracted->>'category' || ' near ' || extracted->>'location',source_post.text,extracted->>'category',extracted->>'severity','Verified',extracted->>'location',13.04,80.22,'AI',source_post.handle,'', (extracted->>'confidence')::numeric,extracted->>'sentiment',source_post.text)
  returning * into result;
  update public.social_posts set status='approved' where id=post_id;
  return result;
end; $$;

alter table public.profiles enable row level security;
alter table public.incidents enable row level security;
alter table public.incident_verifications enable row level security;
alter table public.social_posts enable row level security;

drop policy if exists "Profiles visible to self and admins" on public.profiles;
create policy "Profiles visible to self and admins" on public.profiles for select to authenticated using (id=auth.uid() or public.current_user_is_admin());
drop policy if exists "Users update own safe profile fields" on public.profiles;
create policy "Users update own safe profile fields" on public.profiles for update to authenticated using (id=auth.uid()) with check (id=auth.uid());
drop policy if exists "Incidents readable by authenticated users" on public.incidents;
create policy "Incidents readable by authenticated users" on public.incidents for select to authenticated using (true);
drop policy if exists "Citizens insert their own reports" on public.incidents;
create policy "Citizens insert their own reports" on public.incidents for insert to authenticated with check (reporter_id=auth.uid() and source='Citizen');
drop policy if exists "Admins manage incidents" on public.incidents;
create policy "Admins manage incidents" on public.incidents for update to authenticated using (public.current_user_is_admin()) with check (public.current_user_is_admin());
drop policy if exists "Users read own verification history" on public.incident_verifications;
create policy "Users read own verification history" on public.incident_verifications for select to authenticated using (user_id=auth.uid() or public.current_user_is_admin());
drop policy if exists "Users verify incidents" on public.incident_verifications;
create policy "Users verify incidents" on public.incident_verifications for insert to authenticated with check (user_id=auth.uid());
drop policy if exists "Admins read social posts" on public.social_posts;
create policy "Admins read social posts" on public.social_posts for select to authenticated using (public.current_user_is_admin());
drop policy if exists "Admins manage social posts" on public.social_posts;
create policy "Admins manage social posts" on public.social_posts for all to authenticated using (public.current_user_is_admin()) with check (public.current_user_is_admin());

revoke insert, update, delete on public.profiles, public.incidents, public.incident_verifications, public.social_posts from authenticated;
revoke all on public.profiles, public.incidents, public.incident_verifications, public.social_posts from anon;
grant select on public.profiles, public.incidents, public.incident_verifications, public.social_posts to authenticated;
grant update (full_name, phone, zone) on public.profiles to authenticated;
grant update on public.social_posts to authenticated;
revoke execute on function public.submit_incident(jsonb) from public, anon;
revoke execute on function public.verify_incident(text,text) from public, anon;
revoke execute on function public.admin_set_incident_status(text,text) from public, anon;
revoke execute on function public.admin_convert_social_post(text) from public, anon;
grant execute on function public.submit_incident(jsonb) to authenticated;
grant execute on function public.verify_incident(text,text) to authenticated;
grant execute on function public.admin_set_incident_status(text,text) to authenticated;
grant execute on function public.admin_convert_social_post(text) to authenticated;
grant all privileges on all tables in schema public to service_role;
grant usage, select, update on all sequences in schema public to service_role;
grant execute on all functions in schema public to service_role;

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('incident-evidence', 'incident-evidence', true, 10485760, array['image/jpeg','image/png','image/webp','image/heic'])
on conflict (id) do nothing;
drop policy if exists "Incident evidence is publicly readable" on storage.objects;
create policy "Incident evidence is publicly readable" on storage.objects for select using (bucket_id='incident-evidence');
drop policy if exists "Citizens upload evidence to own folder" on storage.objects;
create policy "Citizens upload evidence to own folder" on storage.objects for insert to authenticated with check (bucket_id='incident-evidence' and (storage.foldername(name))[1]=auth.uid()::text);
